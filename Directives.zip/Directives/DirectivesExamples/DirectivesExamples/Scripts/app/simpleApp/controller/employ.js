﻿// Step1 Create a module.
var employApp = angular.module("employApp", []);



//step2 : Create a controller using module object

employApp.controller("employController", function ($scope) {

    $scope.emploeeList = [
		{ id: 1, name: "Ramesh", designation: "Developer", address: "Bangalore" },
		{ id: 2, name: "Geetha", designation: "Senior Developer", address: "Bangalore" },
		{ id: 3, name: "Gopal", designation: "Architech", address: "Newyork" },
		{ id: 4, name: "Vani", designation: "Developer", address: "Bangalore" }
    ]

    $scope.delete = function(empid)
    {
        //for (i in $scope.emploeeList) {
        //    if ($scope.emploeeList[i].id == empid) {
        //        $scope.emploeeList.splice(i, 1);
        //    }
        //}

        for (var count = 0; count <= $scope.emploeeList.length;count++)
        //for(item in $scope.emploeeList)
        {
            if ($scope.emploeeList[count].id==empid)
            {
                var item = $scope.emploeeList[count];
                //$scope.emploeeList.push(item);
                $scope.emploeeList.splice(item,1);
            }
        }
    }

});

