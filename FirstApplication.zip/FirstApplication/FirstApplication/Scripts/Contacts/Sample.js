﻿var myApp = angular.module("myApp", []);



myApp.controller("myController", ["$scope", function ($scope) {

    $scope.customerInfo = [
        { id: '100', 'Name': 'Satheesh', 'Address': 'Bangalore' },
        { id: '101', 'Name': 'Reka', 'Address': 'Bangalore' },
        { id: '102', 'Name': 'Sai', 'Address': 'Chennai' },
        { id: '103', 'Name': 'Suda', 'Address': 'Hyderabad' },
    ];

}]);