﻿
var app = angular.module('myApp',[]);
var uid = 1;

app.controller('contactController', ['$scope', function ($scope) {

    $scope.contacts = [
        { id: 0, 'name': 'dayakar', 'email': 'daya@gmail.com', 'address': 'Bangalore' },
        { id: 1, 'name': 'Swetha', 'email': 'Swetha@gmail.com', 'address': 'Bangalore' },
        { id: 2, 'name': 'Rekha', 'email': 'Sasi@gmail.com', 'address': 'Singapore' }
    ];

    $scope.saveContact = function () {

        if ($scope.newcontact.id == null) {
            //if this is new contact, add it in contacts array
            $scope.newcontact.id = uid++;
            $scope.contacts.push($scope.newcontact);
        } else {
            //for existing contact, find this contact using id
            //and update it.
            for (i in $scope.contacts) {
                if ($scope.contacts[i].id == $scope.newcontact.id) {
                    $scope.contacts[i] = $scope.newcontact;
                }
            }
        }

        //clear the add contact form
        $scope.newcontact = {};
    }

    $scope.edit = function (id)
    {
        for (item in $scope.contacts)
        {
            if($scope.contacts[item].id===id)
            {
                $scope.newcontact = angular.copy($scope.contacts[item]);
            }
        }
    };

    $scope.delete = function (id) {

        //search contact with given id and delete it
        for (i in $scope.contacts) {
            if ($scope.contacts[i].id == id) {
                $scope.contacts.splice(i, 1);
                $scope.newcontact = {};
            }
        }

    }
}]);