﻿var myApp = angular.module("myApp", []);


myApp.controller("showController", function ($scope) {
    //$scope.cat = false;
    //$scope.aniaml = false;

    $scope.myNumber = 0;
    $scope.isEven = function(value)
    {
        if (value % 2 == 0)
            return true;
        else
            return false;
    }
});