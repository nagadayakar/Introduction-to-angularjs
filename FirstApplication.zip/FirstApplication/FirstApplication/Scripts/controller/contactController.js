﻿var myApp = angular.module("myApp", []);
var uid = 0;

myApp.controller("contactController", ['$scope', function ($scope) {

    $scope.contacts = [
        { id: 1, 'name': 'Raghu', 'email': 'raghu@gmail.com', 'address': 'Bangalore' },
        { id: 2, 'name': 'Nilima', 'email': 'nilima@gmail.com', 'address': 'Bangalore' },
        { id: 3, 'name': 'Ranjith', 'email': 'ranjith@gmail.com', 'address': 'Chennai' },
        { id: 4, 'name': 'Lakshmi', 'email': 'lakshmi@gmail.com', 'address': 'USA' },
    ];

    $scope.products = [
        {productId:1,'name':'labtops', 'price':123},
    ];

    $scope.saveContact = function () {
        uid = $scope.contacts.length + 1;
        if ($scope.contacts.id == null) {
            //if this is new contact, add it in contacts array
            $scope.newcontact.id = uid;
            debugger;
            $scope.contacts.push($scope.newcontact);
        } else {
            //for existing contact, find this contact using id
            //and update it.
            for (i in $scope.contacts) {
                if ($scope.contacts[i].id == $scope.newcontact.id) {
                    $scope.contacts[i] = $scope.newcontact;
                }
            }
        }
    }

    $scope.delete = function(id)
    {
        for (i in $scope.contacts) {
            if ($scope.contacts[i].id == id) {
                $scope.contacts.splice(i, 1);
            }
        }
    }

}]);