﻿var personModule = angular.module("person", []);


//1. define controller

personModule.controller("personController",["$scope", function ($scope) {
    $scope.Persons = [
            {
                Id:1,"Name":"Rahul","Address":"Bangalore"
            },
            {
            Id:2,'Name':"Deepthi","Address":"Bangalore"
            },
            {
            Id:3,'Name':"Kavitha","Address":"Bangalore"
            }
    ]

    $scope.deletePerson = function (id) {
        for (i in $scope.Persons)
        {
            if ($scope.Persons[i].Id == id) {
                $scope.Persons.splice(i, 1);
            }
        }

    }

}]);